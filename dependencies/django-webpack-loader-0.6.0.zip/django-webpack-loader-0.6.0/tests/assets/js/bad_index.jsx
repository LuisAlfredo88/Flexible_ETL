var React = require('the-library-that-did-not-exist');
var App = require('./app');
var style = require('./style.css');

React.render(<App/>, document.getElementById('react-app'));
