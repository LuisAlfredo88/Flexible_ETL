var React = require('react');
var App = require('./app');
var style = require('./style.css');

React.render(<App/>, document.getElementById('react-app'));
