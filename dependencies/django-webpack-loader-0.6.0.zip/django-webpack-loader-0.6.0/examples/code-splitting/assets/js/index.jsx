var React = require('react');
var App = require('./app');

React.render(<App/>, document.getElementById('react-app'));
